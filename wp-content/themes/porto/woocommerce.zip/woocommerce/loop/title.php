<?php
/**
 * Product loop title
 *
 * @version 2.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<h3><?php the_title(); ?></h3>
