<div class="caldera-config-group">
	<label for="{{_id}}_default_color">
        <?php esc_html_e('Default Color', 'caldera-forms' ); ?>
    </label>
	<div class="caldera-config-field">
		<input id="{{_id}}_default_color" type="text" class="color-field field-config" name="{{_name}}[default]" value="{{default}}">
	</div>
</div>