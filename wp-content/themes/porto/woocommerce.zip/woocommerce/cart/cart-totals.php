<?php
/**
 * Cart totals
 *
 * @version     2.3.6
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_template_part( 'woocommerce/cart/cart-totals', porto_cart_version() );
